package com.iteso.test;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.support.v4.app.Fragment;

import com.iteso.test.beans.ItemProduct;

import java.util.ArrayList;

public class FragmentTechnology extends Fragment {
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<ItemProduct> myDataSet;
    private RecyclerView recyclerView;



    public FragmentTechnology() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_technology,container,false);
        recyclerView = view.findViewById(R.id.fragment_technology_recycler_view);
        recyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);

        if(myDataSet == null){
            myDataSet = new ArrayList<>();
            ItemProduct mac = new ItemProduct();
            mac.setTitle("Macbook Pro 17");
            mac.setStore("Best Buy");
            mac.setLocation("Zapopan, Jalisco");
            mac.setPhone("3312345678");
            mac.setImage(0);
            mac.setCode(0);
            mac.setDescription("Asombrosa Mac");
            myDataSet.add(mac);


            ItemProduct alienware = new ItemProduct();
            alienware.setTitle("Alienware 17");
            alienware.setStore("Zapopan, Jalisco");
            alienware.setLocation("Best Buy");
            alienware.setPhone("3312345678");
            alienware.setImage(1);
            alienware.setCode(1);
            alienware.setDescription("Asombrosa Windows");
            myDataSet.add(alienware);
        }

        mAdapter = new AdapterProduct(getActivity(), myDataSet);
        recyclerView.setAdapter(mAdapter);
        return view;
    }

    public void itemChanges(ItemProduct itemProduct, int index) {
        myDataSet.set(index, itemProduct);
        mAdapter = new AdapterProduct(getActivity(), myDataSet);
        recyclerView.setAdapter(mAdapter);
    }


}